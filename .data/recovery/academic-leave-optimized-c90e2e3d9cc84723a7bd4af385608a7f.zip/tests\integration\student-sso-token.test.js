import assert from 'node:assert/strict';
import test from 'node:test';
import {createHash,randomUUID} from 'node:crypto';
import jwt from 'jsonwebtoken';
import {createAuthService} from '../../src/modules/auth/services/auth.service.js';
import {createAuthStore} from '../../src/modules/auth/stores/auth.store.js';
import {hashPassword} from '../../src/modules/auth/services/password.service.js';
import {createSsoTokenResolver,createLocalPermissionContext} from '../../src/modules/auth/index.js';

const password='Synthetic-password-!42';
const passwordHash=await hashPassword(password);
function fixture(t){
  let time=Date.now();
  const config={nodeEnv:'test',auth:{stateTtlMs:600000,handoffTtlMs:60000,refreshTtlSeconds:604800},
    jwt:{secret:'local-admin-test-signing-key-at-least-32-bytes',expiresIn:'15m',issuer:'fixture-api',studentAudience:'fixture-student',adminAudience:'fixture-admin'},
    app:{url:'http://localhost:3003',studentFrontendUrl:'http://localhost:5173',adminFrontendUrl:'http://localhost:5174'},
    microsoftSso:{baseUrl:'https://sso.example.test',loginPath:'/microsoft/login',logoutPath:'/microsoft/logout',
      studentCallbackUrl:'http://localhost:3003/api/student/auth/microsoft/callback',studentFrontendCallbackUrl:'http://localhost:5173/auth-callback.html',
      jwtSecret:'sso-fixture-key-distinct-from-admin-key',jwtIssuer:'fixture-sso',allowMissingAudience:true}};
  const store=createAuthStore({now:()=>time});t.after(()=>store.close());
  const account={id:'00000000-0000-4000-8000-000000000001',username:'staff.fixture',displayName:'Fixture staff',passwordHash,
    channel:'admin',isActive:true,version:'fixture-v1',roles:['reviewer'],permissions:['certifications:review']};
  const repository={findLocalByUsername:async name=>name===account.username?account:null,findLocalById:async id=>id===account.id?account:null};
  const service=createAuthService({config,store,repository,now:()=>time});
  const sign=(claims={},options={})=>jwt.sign({sub:'sso-fixture',unique_name:'fixture@school.example',name:'SSO fixture',
    roles:['admin'],permissions:['certifications:review'],iat:Math.floor(time/1000),...claims},config.microsoftSso.jwtSecret,
    {algorithm:'HS256',issuer:config.microsoftSso.jwtIssuer,expiresIn:'2m',...options});
  const login=async token=>{const pending=await service.exchangeToken('student',token),handoff=service.createHandoff('student',pending);
    return service.redeemHandoff('student',handoff.code,handoff.binding);};
  return{config,store,service,account,sign,login,advance:ms=>{time+=ms;}};
}

test('student APIs accept the original SSO token; web login and restoration never replace it or extend its expiry',async t=>{
  const f=fixture(t),upstream=f.sign();
  const direct=await f.service.verifyToken(upstream,'student');
  assert.equal(direct.authMethod,'sso');assert.deepEqual(direct.roles,['student']);assert.deepEqual(direct.permissions,[]);
  const request={headers:{authorization:'Bearer '+upstream}};
  assert.equal(await createSsoTokenResolver(f.service)(request),upstream);assert.equal(request.ssoAccessToken,upstream);
  const issued=await f.login(upstream);
  assert.equal(issued.data.accessToken,upstream);assert.equal(issued.data.token,upstream);assert.equal(issued.data.tokenSource,'sso');
  assert.equal(issued.data.expiresAt,new Date(jwt.decode(upstream).exp*1000).toISOString());
  assert.match(issued.refreshToken,/^[A-Za-z0-9_-]{43}$/);assert.equal(jwt.decode(issued.refreshToken),null);
  assert.ok(issued.maxAge<=120000);
  const restored=await f.service.refreshSession('student',issued.refreshToken);
  assert.equal(restored.data.accessToken,upstream);assert.notEqual(restored.refreshToken,issued.refreshToken);
  assert.equal(restored.data.expiresAt,issued.data.expiresAt);
  f.advance(121000);
  await assert.rejects(f.service.verifyToken(upstream,'student'),error=>error.statusCode===401);
  await assert.rejects(f.service.refreshSession('student',restored.refreshToken),error=>error.statusCode===401);
});

test('only admin/password sign-in issues application JWTs; student SSO cannot authenticate as staff',async t=>{
  const f=fixture(t),upstream=f.sign();
  await assert.rejects(f.service.loginWithPassword('student',{username:f.account.username,password}),error=>error.statusCode===403);
  await assert.rejects(createLocalPermissionContext('certifications:review',f.service)({headers:{authorization:'Bearer '+upstream}}),error=>error.statusCode===401);
  const admin=await f.service.loginWithPassword('admin',{username:f.account.username,password});
  assert.equal(admin.data.tokenSource,'application');assert.equal(jwt.decode(admin.data.accessToken,{complete:true}).header.typ,'at+jwt');
  assert.equal((await f.service.verifyToken(admin.data.accessToken,'admin')).authMethod,'password');
  await assert.rejects(f.service.verifyToken(admin.data.accessToken,'student'),error=>error.statusCode===401);
  const staff=await createLocalPermissionContext('certifications:review',f.service)({headers:{authorization:'Bearer '+admin.data.accessToken}});
  assert.equal(staff.role,'reviewer');
  const refreshed=await f.service.refreshSession('admin',admin.refreshToken);
  await f.service.verifyToken(refreshed.data.accessToken,'admin');
  f.service.logoutSession('admin',refreshed.refreshToken);
  await assert.rejects(f.service.verifyToken(admin.data.accessToken,'admin'),error=>error.statusCode===401);
});

test('student validation rejects wrong issuer, audience, signature, algorithm and missing expiry',async t=>{
  const f=fixture(t);
  const invalid=[f.sign({}, {issuer:'wrong'}),f.sign({aud:'unexpected-audience'}),f.sign({}, {algorithm:'HS384'}),
    jwt.sign({unique_name:'fixture',iss:f.config.microsoftSso.jwtIssuer},f.config.microsoftSso.jwtSecret),
    jwt.sign({unique_name:'fixture'},'untrusted-key',{expiresIn:'1h',issuer:f.config.microsoftSso.jwtIssuer})];
  for(const token of invalid)await assert.rejects(f.service.getSsoAccessToken(token),error=>error.statusCode===401);
});

test('local student logout revokes the upstream token in this app; a new SSO handoff can sign in again',async t=>{
  const f=fixture(t),upstream=f.sign(),session=await f.login(upstream);
  f.service.logoutSession('student',session.refreshToken);
  await assert.rejects(f.service.verifyToken(upstream,'student'),error=>error.statusCode===401);
  const again=await f.login(upstream);
  assert.equal(again.data.accessToken,upstream);await f.service.verifyToken(upstream,'student');
  f.service.revokeSession('student',await f.service.verifyToken(upstream,'student'));
  await assert.rejects(f.service.getSsoAccessToken(upstream),error=>error.statusCode===401);
});

test('an existing student refresh cookie migrates to the original SSO token and an opaque browser cookie',async t=>{
  const f=fixture(t),upstream=f.sign(),pending=await f.service.exchangeToken('student',upstream);
  const session={...pending,id:randomUUID(),channel:'student',expiresAt:Date.now()+604800000};
  const legacy=jwt.sign({tokenUse:'refresh',sid:session.id,authMethod:'sso',channel:'student'},f.config.jwt.secret,
    {algorithm:'HS256',issuer:f.config.jwt.issuer,audience:f.config.jwt.studentAudience,subject:session.subject,
      jwtid:randomUUID(),expiresIn:'7d',header:{typ:'refresh+jwt'}});
  f.store.createSession(session,createHash('sha256').update(legacy).digest('hex'));
  const migrated=await f.service.refreshSession('student',legacy);
  assert.equal(migrated.data.accessToken,upstream);assert.match(migrated.refreshToken,/^[A-Za-z0-9_-]{43}$/);
});
