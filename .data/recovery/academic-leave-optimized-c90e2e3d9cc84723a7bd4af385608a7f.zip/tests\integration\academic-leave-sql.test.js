import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {randomBytes} from 'node:crypto';
import test from 'node:test';
import express from 'express';
import {queryLocalDatabase as nativeQuery,disconnectAllDatabases} from '../../src/infrastructure/database/index.js';
import {createAcademicLeaveRepository} from '../../src/modules/academic-leave/repositories/academic-leave.repository.js';
import {createAcademicLeaveModule} from '../../src/modules/academic-leave/index.js';
import {AppError} from '../../src/shared/errors/app-error.js';
import {errorHandler} from '../../src/shared/middlewares/error-handler.middleware.js';

test('SQL leave workflow preserves snapshots, enforces ownership/relationships/limits, reviews, extensions and paper deadlines',
  {skip:process.env.LEAVE_DB_TEST!=='1'},async t=>{
  const schema='test_leave_'+randomBytes(6).toString('hex');
  const migration=(await readFile('docs/sql/academic-leave.sql','utf8')).replaceAll('academic_leave',schema);
  await nativeQuery(migration);await nativeQuery(migration);
  t.after(async()=>{await nativeQuery(`DROP TABLE ${schema}.Applications; DROP SCHEMA ${schema};`);await disconnectAllDatabases();});
  const query=(statement,parameters)=>nativeQuery(statement.replaceAll('academic_leave.',schema+'.'),parameters);
  const repository=createAcademicLeaveRepository({query,connect:async()=>({request:()=>({query:async()=>({recordset:[{code:'2610'}]})})})});
  const actor={role:'student',source:'auth',reference:'fixture-one',name:'Synthetic Student',studentCode:'999260001'};
  const reviewer={role:'reviewer',source:'manual',reference:'fixture-reviewer',name:'Fixture reviewer'};
  let profileName='Synthetic Student';
  const studentProfile=account=>({studentCode:account.studentCode,fullName:profileName,birthday:'2005-02-20',
    className:'TEST',phoneNumber:'0000000000',cccd:'000000000001'});
  const snapshotProvider=async account=>({student:studentProfile(account),academicRows:[{semester:'2510',credits:18,gpa:3.8,conduct:82}]});
  const module=createAcademicLeaveModule({repository,snapshotProvider,prefillProvider:async account=>({student:studentProfile(account)}),renderPdf:async()=>Buffer.from('%PDF-fixture'),
    studentContextProvider:async req=>{
      if(req.headers.authorization==='Bearer fixture-student')return actor;
      if(req.headers.authorization==='Bearer fixture-other')return{...actor,reference:'fixture-other',studentCode:'999260002'};
      throw new AppError('Need login',401);
    },reviewerContextProvider:async req=>{if(req.headers.cookie==='fixture=reviewer')return reviewer;throw new AppError('Need reviewer',401);}});
  const app=express();app.use(express.json());app.use(module.basePath,module.router);app.use(errorHandler);
  const server=createServer(app);await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>{server.close(resolve);server.closeAllConnections();}));
  const base='http://127.0.0.1:'+server.address().port+module.basePath;
  async function request(path,{method='GET',body,version,reviewer=false,other=false,auth=true,expected=200,html=false}={}){
    const response=await fetch(base+path,{method,headers:{...(auth&&!reviewer?{Authorization:'Bearer '+(other?'fixture-other':'fixture-student')} :{}),
      ...(reviewer?{Cookie:'fixture=reviewer'}:{}),...(body?{'Content-Type':'application/json'}:{}),...(version?{'If-Match':'"'+version+'"'}:{})},...(body?{body:JSON.stringify(body)}:{})});
    const result=html?await response.text():await response.json();assert.equal(response.status,expected,JSON.stringify(result));return html?result:result.data;
  }
  await request('/form',{auth:false,expected:401});
  const form=await request('/form');assert.equal(form.maxSemesterCount,4);assert.equal(form.paperSubmissionDays,3);
  assert.deepEqual(form.semesters.map(item=>item.code),['2520','2610','2620']);assert.equal(form.reasons.length,4);
  const data={kind:'leave',reasonCode:'medical',startSemesterCode:'2610',semesterCount:1,content:'Fixture'};
  await request('/applications',{method:'POST',body:{...data,semesterCount:5},expected:400});
  await request('/applications',{method:'POST',body:{...data,studentCode:'999260002'},expected:400});
  let row=await request('/applications',{method:'POST',body:data,expected:201});const id=row.id;
  assert.equal(row.status,'draft');assert.equal(row.studentSequence,1);assert.equal(row.requestCode,'NH9992600011');assert.equal((await request('/applications')).totalRecords,1);
  assert.equal((await request('/applications',{other:true})).totalRecords,0);
  await request('/applications/'+id,{other:true,expected:404});
  await request('/applications/'+id+'/print',{expected:409});
  await request('/applications/'+id,{method:'PUT',body:data,expected:428});
  await request('/applications/'+id,{method:'PUT',body:data,version:'0000000000000000',expected:409});
  const initialVersion=row.rowVersion;
  row=await request('/applications/'+id+'/confirm',{method:'POST',body:{},version:row.rowVersion});assert.equal(row.status,'submitted');
  profileName='Changed profile after confirmation';
  const printed=await request('/applications/'+id+'/print',{html:true});assert.match(printed,/Synthetic Student/);assert.doesNotMatch(printed,/Changed profile/);
  const beforePrint=await repository.get(actor,id);
  const pdf=await fetch(base+'/print?MADN='+row.requestCode,{headers:{Authorization:'Bearer fixture-student'}});
  assert.equal(pdf.status,200);assert.match(pdf.headers.get('content-type'),/^application\/pdf/);assert.match(await pdf.text(),/^%PDF-/);
  assert.deepEqual(await repository.get(actor,id),beforePrint);
  await request('/print?MADN='+row.requestCode,{other:true,expected:404});
  await request('/applications/'+id,{method:'PUT',body:data,version:row.rowVersion,expected:409});
  await request('/reviewer/applications',{expected:403});await request('/reviewer/applications',{auth:false,expected:401});
  assert.equal((await request('/reviewer/applications',{reviewer:true})).items[0].id,id);
  await request('/reviewer/applications/'+id+'/review',{method:'POST',reviewer:true,version:initialVersion,body:{decision:'approved'},expected:409});
  row=await request('/reviewer/applications/'+id+'/review',{method:'POST',reviewer:true,version:row.rowVersion,body:{decision:'needs_changes',note:'Clarify content'}});
  assert.equal(row.status,'needs_changes');
  row=await request('/applications/'+id,{method:'PUT',version:row.rowVersion,body:{...data,content:'Amended'}});
  row=await request('/applications/'+id+'/confirm',{method:'POST',body:{},version:row.rowVersion});assert.equal(row.reviewNote,null);
  row=await request('/reviewer/applications/'+id+'/review',{method:'POST',reviewer:true,version:row.rowVersion,body:{decision:'approved',note:'Valid'}});
  assert.equal(Date.parse(row.paperDeadlineAt)-Date.parse(row.reviewedAt),3*86400000);
  row=await request('/reviewer/applications/'+id+'/receive-paper',{method:'POST',reviewer:true,version:row.rowVersion,body:{}});
  assert.equal(row.status,'paper_received');assert.ok(row.paperReceivedAt);
  let otherDraft=await request('/applications',{method:'POST',other:true,body:data,expected:201});
  assert.equal(otherDraft.studentSequence,1);assert.equal(otherDraft.requestCode,'NH9992600021');
  await request('/applications/'+otherDraft.id+'/cancel',{method:'POST',other:true,version:otherDraft.rowVersion,body:{}});
  const extension={...data,kind:'extension',parentApplicationId:id,startSemesterCode:'2620',semesterCount:4};
  await request('/applications',{method:'POST',body:{...extension,startSemesterCode:'2610'},expected:409});
  await request('/applications',{method:'POST',other:true,body:extension,expected:404});
  let child=await request('/applications',{method:'POST',body:extension,expected:201});assert.equal(child.endSemester.code,'2810');
  assert.equal(child.studentSequence,2);assert.equal(child.requestCode,'NH9992600012');assert.notEqual(child.id,child.studentSequence);
  child=await request('/applications/'+child.id+'/confirm',{method:'POST',body:{},version:child.rowVersion});
  child=await request('/reviewer/applications/'+child.id+'/review',{method:'POST',reviewer:true,version:child.rowVersion,body:{decision:'approved'}});
  assert.match(await request('/applications/'+child.id+'/print',{html:true}),/GIA HẠN NGỪNG HỌC/);
  await request('/applications',{method:'POST',body:extension,expected:409});
  let overlap=await request('/applications',{method:'POST',body:{...data,semesterCount:2},expected:201});
  await request('/applications/'+overlap.id+'/confirm',{method:'POST',body:{},version:overlap.rowVersion,expected:409});
  overlap=await request('/applications/'+overlap.id+'/cancel',{method:'POST',body:{},version:overlap.rowVersion});assert.equal(overlap.status,'cancelled');
  await nativeQuery(`UPDATE ${schema}.Applications SET ReviewedAt=DATEADD(day,-4,SYSUTCDATETIME()),PaperDeadlineAt=DATEADD(day,-1,SYSUTCDATETIME()) WHERE Id=?`,[child.id]);
  child=await request('/applications/'+child.id);assert.equal(child.overdue,true);
  await request('/reviewer/applications/'+child.id+'/receive-paper',{method:'POST',reviewer:true,version:child.rowVersion,body:{},expected:409});
  await assert.rejects(nativeQuery(`UPDATE ${schema}.Applications SET SemesterCount=5 WHERE Id=?`,[child.id]));
  await assert.rejects(nativeQuery(`UPDATE ${schema}.Applications SET ParentApplicationId=2147483647 WHERE Id=?`,[child.id]));
  assert.equal((await request('/applications/'+child.id)).semesterCount,4);
  const raceActor={...actor,reference:'fixture-race',studentCode:'999260003'};
  const racing=await Promise.allSettled([repository.save(raceActor,data),repository.save(raceActor,data)]);
  assert.equal(racing.filter(result=>result.status==='fulfilled').length,1);
  const winner=racing.find(result=>result.status==='fulfilled').value;assert.equal(winner.studentSequence,1);
  await repository.cancel(raceActor,winner.id,winner.rowVersion);
  const next=await repository.save(raceActor,data);assert.equal(next.studentSequence,2);
});

test('student sequence migration preserves already issued request codes and confirmed data',
  {skip:process.env.LEAVE_DB_TEST!=='1'},async t=>{
  const schema='test_leave_'+randomBytes(6).toString('hex');
  const migration=(await readFile('docs/sql/academic-leave.sql','utf8')).replaceAll('academic_leave',schema);
  await nativeQuery(migration);
  t.after(async()=>{await nativeQuery(`DROP TABLE ${schema}.Applications; DROP SCHEMA ${schema};`);await disconnectAllDatabases();});
  await nativeQuery(`ALTER TABLE ${schema}.Applications DROP CONSTRAINT UQ_AcademicLeave_Code;
    ALTER TABLE ${schema}.Applications DROP CONSTRAINT CK_AcademicLeave_Sequence;
    DROP INDEX UX_AcademicLeave_StudentSequence ON ${schema}.Applications;
    ALTER TABLE ${schema}.Applications DROP COLUMN RequestCode;
    ALTER TABLE ${schema}.Applications DROP COLUMN StudentSequence;
    ALTER TABLE ${schema}.Applications ADD RequestCode AS (CONVERT(varchar(2),'NH')+StudentCode+CONVERT(varchar(10),Id)) PERSISTED;
    ALTER TABLE ${schema}.Applications ADD CONSTRAINT UQ_AcademicLeave_Code UNIQUE(RequestCode);
    INSERT ${schema}.Applications(StudentCode,ActorSource,ActorReference,Kind,ReasonCode,StartSemesterCode,SemesterCount,Status,SnapshotJson)
      VALUES('999260001','auth','fixture-one','leave','medical','2610',1,'cancelled',N'{"student":{"fullName":"Fixture one"}}'),
        ('999260002','auth','fixture-two','leave','medical','2610',1,'cancelled',N'{"student":{"fullName":"Fixture two"}}');`);
  const select=`SELECT Id,RequestCode,SnapshotJson FROM ${schema}.Applications ORDER BY Id`;
  const before=(await nativeQuery(select)).first;
  await nativeQuery(migration);await nativeQuery(migration);
  assert.deepEqual((await nativeQuery(select)).first,before);
  const repository=createAcademicLeaveRepository({query:(text,params)=>nativeQuery(text.replaceAll('academic_leave.',schema+'.'),params)});
  const input={kind:'leave',reasonCode:'medical',startSemesterCode:'2610',semesterCount:1,content:''};
  const existing=await repository.save({role:'student',source:'auth',reference:'fixture-two',studentCode:'999260002'},input);
  assert.equal(existing.requestCode,'NH9992600023');assert.equal(existing.studentSequence,3);
  const fresh=await repository.save({role:'student',source:'auth',reference:'fixture-new',studentCode:'999260003'},input);
  assert.equal(fresh.requestCode,'NH9992600031');
});
