import assert from 'node:assert/strict';
import test from 'node:test';
import {setImmediate as tick} from 'node:timers/promises';
import jwt from 'jsonwebtoken';
import {createAuthService} from '../../src/modules/auth/services/auth.service.js';
import {createAuthStore} from '../../src/modules/auth/stores/auth.store.js';
import {createSsoTokenResolver} from '../../src/modules/auth/index.js';
import {createDutStudentContext,createStudentApplicationDataService,createStudentService} from '../../src/modules/students/index.js';
import {createAcademicLeaveRepository} from '../../src/modules/academic-leave/repositories/academic-leave.repository.js';
import {createAcademicLeaveService} from '../../src/modules/academic-leave/services/academic-leave.service.js';

const studentCode='999240001';
const actor={role:'student',source:'auth',reference:'dut-student:'+studentCode,studentCode,name:'Token name',
  className:'24T1',cccd:'000000000001',birthday:'2005-02-20',phoneNumber:'0900000001'};
function authentication(t){
  let time=Date.now();
  const config={nodeEnv:'test',jwt:{secret:'local-fixture-secret-at-least-32-characters',expiresIn:'15m'},
    microsoftSso:{jwtSecret:'sso-fixture-key-distinct-from-local-key',jwtIssuer:'fixture-sso',allowMissingAudience:true,studentEmailDomains:['sv1.dut.udn.vn']}};
  const store=createAuthStore({now:()=>time});t.after(()=>store.close());
  const service=createAuthService({config,store,now:()=>time});
  const sign=(claims={})=>jwt.sign({sub:'fixture-sub',unique_name:studentCode+'@sv1.dut.udn.vn',iat:Math.floor(time/1000),...claims},
    config.microsoftSso.jwtSecret,{algorithm:'HS256',issuer:config.microsoftSso.jwtIssuer,expiresIn:'5m'});
  const request=token=>({headers:{authorization:'Bearer '+token}});
  return{config,store,service,sign,request,now:()=>time,advance:ms=>{time+=ms;}};
}

test('a verified school UPN resolves MSSV without profile HTTP; other domains never supply a student code by prefix',async t=>{
  const f=authentication(t);let profileCalls=0;
  const context=createDutStudentContext({ssoConfig:f.config.microsoftSso,ssoTokenResolver:createSsoTokenResolver(f.service),
    fetchImpl:async()=>{profileCalls++;return Response.json({data:{studentCardNumber:'999240002',fullName:'Profile fixture'}});}});
  const resolved=await context(f.request(f.sign()));
  assert.equal(resolved.studentCode,studentCode);assert.equal(resolved.name,null);assert.equal(profileCalls,0);
  const other=await context(f.request(f.sign({unique_name:studentCode+'@untrusted.example'})));
  assert.equal(other.studentCode,'999240002');assert.equal(profileCalls,1);
  await assert.rejects(context(f.request(f.sign({studentCode:'999240003'}))),error=>error.statusCode===403);
  assert.equal(profileCalls,1);
});

test('fallback profile requests share in-flight work, expire promptly, and never bypass token revocation or expiry',async t=>{
  const f=authentication(t),gate=Promise.withResolvers();let queries=0,authChecks=0;
  const resolve=createSsoTokenResolver(f.service),token=f.sign({unique_name:'nonstandard@dut.udn.vn'});
  const context=createDutStudentContext({ssoConfig:f.config.microsoftSso,now:f.now,profileTtlMs:1000,
    ssoTokenResolver:async req=>{authChecks++;return resolve(req);},fetchImpl:async()=>{
      queries++;await gate.promise;return Response.json({data:{studentCardNumber:studentCode,fullName:'Cached profile'}});
    }});
  const first=context(f.request(token)),second=context(f.request(token));await tick();
  assert.equal(queries,1);gate.resolve();await Promise.all([first,second]);
  await context(f.request(token));assert.equal(queries,1);assert.equal(authChecks,3);
  f.advance(1001);await context(f.request(token));assert.equal(queries,2);
  f.service.revokeSession('student',await f.service.verifyToken(token,'student'));
  await assert.rejects(context(f.request(token)),error=>error.statusCode===401);assert.equal(queries,2);
  const fresh=f.sign({unique_name:'another@dut.udn.vn'});await context(f.request(fresh));assert.equal(queries,3);
  f.advance(301000);await assert.rejects(context(f.request(fresh)),error=>error.statusCode===401);assert.equal(queries,3);
});

test('application personal fields prefer verified claims and use one SQL lookup only for missing fields',async()=>{
  let queries=0;
  const service=createStudentService({repository:{findIdentityRowsByStudentCode:async code=>{
    queries++;assert.equal(code,studentCode);return[{studentCode,fullName:'DB name',className:'DB class',citizenId:'000000000002',
      birthDay:'21',birthMonth:'2',birthYear:'2005',phoneNumber:'0900000002'}];
  }}});
  const complete=await service.getApplicationProfile(actor);assert.equal(complete.fullName,actor.name);assert.equal(queries,0);
  const partial=await service.getApplicationProfile({role:'student',studentCode,name:actor.name});
  assert.equal(partial.fullName,actor.name);assert.equal(partial.className,'DB class');assert.equal(partial.birthday,'2005-02-21');
  assert.equal(partial.cccd,'000000000002');assert.equal(partial.phoneNumber,'0900000002');assert.equal(queries,1);
});

test('opening forms, listing and saving drafts never fetch academic statistics; only confirmation freezes them for printing',async()=>{
  let stats=0,allowStats=false,row;
  const input={kind:'leave',reasonCode:'medical',startSemesterCode:'2610',semesterCount:1,content:''};
  const data=createStudentApplicationDataService({identityService:{getApplicationProfile:async()=>({studentCode,fullName:actor.name,
    className:actor.className,cccd:actor.cccd,birthday:actor.birthday,phoneNumber:actor.phoneNumber})},
    academicRepository:{statistics:async token=>{assert.equal(allowStats,true);assert.equal(token,'upstream-fixture');stats++;
      return{semesters:['2610'],creditsPerSemester:[18],gpaPerSemester:[3.5],conductPerSemester:[90]};}}});
  const repository={currentSemesterCode:async()=> '2610',eligibleParents:async()=>[],
    list:async()=>({items:row?[row]:[],totalRecords:row?1:0}),get:async()=>row,getByRequestCode:async()=>row,
    save:async(_actor,input)=>row={...input,id:1,studentCode,requestCode:'NH'+studentCode+'1',status:'draft',rowVersion:'0000000000000001'},
    confirm:async(_actor,id,version,snapshot)=>row={...row,status:'submitted',snapshot,studentConfirmedAt:'2026-11-02T00:00:00Z',rowVersion:'0000000000000002'}};
  const service=createAcademicLeaveService({repository,prefillProvider:account=>data.prefill(account),snapshotProvider:(account,token)=>data.snapshot(account,token)});
  const form=await service.form(actor,'upstream-fixture');assert.equal(form.prefill.student.fullName,actor.name);
  assert.equal('academicRows' in form.prefill,false);await service.list(actor,{});const draft=await service.save(actor,input);assert.equal(stats,0);
  allowStats=true;const confirmed=await service.confirm(actor,draft.id,draft.rowVersion,'upstream-fixture');assert.equal(stats,1);
  assert.deepEqual(confirmed.snapshot.academicRows,[{semester:'2610',credits:18,gpa:3.5,conduct:90}]);
  allowStats=false;await service.get(actor,1);await service.printable(actor,1);await service.printableByCode(actor,row.requestCode);assert.equal(stats,1);
});

test('form semester lookups are shared and cached briefly while submission validation always rechecks current school settings',async()=>{
  let queries=0,time=0,code='2610';
  const repository=createAcademicLeaveRepository({now:()=>time,semesterCacheTtlMs:1000,connect:async(account,database)=>{
    assert.equal(account,'secondary');assert.equal(database,'DATA_GVien1');
    return{request:()=>({query:async()=>{queries++;return{recordset:[{code}]};}})};
  }});
  assert.deepEqual(await Promise.all([repository.currentSemesterCode(),repository.currentSemesterCode()]),['2610','2610']);assert.equal(queries,1);
  code='2620';assert.equal(await repository.currentSemesterCode(),'2610');assert.equal(queries,1);
  assert.equal(await repository.currentSemesterCode({fresh:true}),'2620');assert.equal(queries,2);
  time=1001;assert.equal(await repository.currentSemesterCode(),'2620');assert.equal(queries,3);
});
