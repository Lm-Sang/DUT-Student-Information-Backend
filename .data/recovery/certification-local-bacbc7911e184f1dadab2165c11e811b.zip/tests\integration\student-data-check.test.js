import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import test from 'node:test';
import {createWebTestApp} from '../../certification-web-test/server.js';
import {studentDataEndpoints} from '../../certification-web-test/student-data-check.js';

async function listen(t, options) {
  const app=createWebTestApp({apiBaseUrl:'http://localhost:3003',ssoBaseUrl:'https://sso.dut.udn.vn',...options,
    studentDataCheck:{ssoTokenResolver:async req=>req.headers.authorization?.slice(7),identityLookup:async()=>({status:'missing',cccd:null,source:'fixture'}),...options?.studentDataCheck}});
  const server=createServer(app);
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>{server.close(resolve);server.closeAllConnections();}));
  return 'http://127.0.0.1:'+server.address().port;
}

test('student diagnostic uses only fixed GET endpoints, filters credentials and saves no personal values in its summary',async t=>{
  const calls=[],summaries=[];
  const base=await listen(t,{studentDataCheck:{onSummary:summary=>summaries.push(summary),fetchImpl:async(url,options)=>{
    calls.push({url,options});
    if(url===studentDataEndpoints.profile)return Response.json({data:{fullName:'Synthetic Student',studentCardNumber:'999240001',
      birthday:'2005-01-01',phoneNumber:'0000000000',cccd:'000000000001',class:{name:'TEST'},accessToken:'test-token',nested:{secret:'hidden'}}});
    if(url===studentDataEndpoints.stats)return Response.json({data:{semesters:['2024-1','2024-2'],creditsPerSemester:[18,20],
      gpaPerSemester:[0,null],conductPerSemester:[80,90]}});
    return Response.json({data:[{subjectCode:'TEST101',credits:3,score4:0}]});
  }}});
  const response=await fetch(base+'/local-api/student-data-check',{headers:{Authorization:'Bearer test-token'}});
  assert.equal(response.status,200);assert.equal(response.headers.get('cache-control'),'no-store');
  const body=await response.json();
  assert.equal(body.endpoints.profile.body.data.cccd,'000000000001');
  assert.equal(body.endpoints.profile.body.data.accessToken,'[redacted]');
  assert.equal(body.endpoints.profile.body.data.nested.secret,'[redacted]');
  assert.deepEqual(body.endpoints.stats.body.data.gpaPerSemester,[0,null]);
  assert.deepEqual(calls.map(call=>call.url).sort(),Object.values(studentDataEndpoints).sort());
  for(const {options} of calls){assert.equal(options.method,'GET');assert.equal(options.redirect,'error');assert.equal(options.headers.Authorization,'Bearer test-token');}
  const report=JSON.stringify(summaries);
  for(const privateValue of ['Synthetic Student','999240001','2005-01-01','000000000001','test-token'])assert.ok(!report.includes(privateValue));
  assert.ok(summaries[0].endpoints.profile.fields.some(field=>field.path==='data.cccd'&&field.present));
  assert.equal(summaries[0].endpoints.results.fields.find(field=>field.path==='data').count,1);
});

test('student diagnostic rejects missing auth, queries and reviewer requests before any upstream call',async t=>{
  let count=0;
  const studentDataCheck={fetchImpl:async()=>{count++;throw new Error('not expected');}};
  const base=await listen(t,{studentDataCheck});
  assert.equal((await fetch(base+'/local-api/student-data-check')).status,401);
  assert.equal((await fetch(base+'/local-api/student-data-check?url=https://example.com',{headers:{Authorization:'Bearer test-token'}})).status,400);
  const reviewer=await listen(t,{mode:'reviewer',studentDataCheck});
  assert.equal((await fetch(reviewer+'/local-api/student-data-check',{headers:{Authorization:'Bearer test-token'}})).status,404);
  assert.equal((await fetch(base+'/local-api/student-data-check',{method:'POST',headers:{Authorization:'Bearer test-token'}})).status,404);
  assert.equal(count,0);
});

test('student diagnostic keeps endpoint failures separate and never returns upstream error bodies',async t=>{
  const base=await listen(t,{studentDataCheck:{fetchImpl:async url=>{
    if(url===studentDataEndpoints.profile)return new Response('private upstream detail',{status:401});
    if(url===studentDataEndpoints.stats)return Response.json({isSuccess:false,statusCode:403,message:'private upstream detail'});
    return Response.json({data:[]});
  }}});
  const response=await fetch(base+'/local-api/student-data-check',{headers:{Authorization:'Bearer test-token'}});
  const text=await response.text(),body=JSON.parse(text);
  assert.equal(body.endpoints.profile.status,401);assert.equal(body.endpoints.stats.status,403);
  assert.equal(body.endpoints.results.ok,true);assert.ok(!text.includes('private upstream detail'));
});

test('CCCD lookup uses only the authenticated profile MSSV and excludes the number from the saved summary',async t=>{
  const lookups=[],summaries=[];
  const base=await listen(t,{studentDataCheck:{onSummary:summary=>summaries.push(summary),
    identityLookup:async actor=>{lookups.push(actor);return{status:'found',cccd:'000000000001',source:'DATA_SV1.dbo.NhanThan.CCCD_So'};},
    fetchImpl:async url=>Response.json({data:url===studentDataEndpoints.profile?{fullName:'Synthetic Student',studentCardNumber:'999240001'}:[]})}});
  const response=await fetch(base+'/local-api/student-data-check',{headers:{Authorization:'Bearer test-token','X-Student-Code':'999240002'}});
  const body=await response.json();
  assert.deepEqual(lookups,[{role:'student',studentCode:'999240001'}]);
  assert.equal(body.endpoints.identity.body.data.cccd,'000000000001');
  assert.ok(!JSON.stringify(summaries).includes('000000000001'));
  assert.ok(!JSON.stringify(summaries).includes('999240001'));
});

test('profile rejection or malformed identity never triggers a DB lookup; a DB failure preserves the other API results',async t=>{
  let lookups=0;
  for(const profile of [new Response(null,{status:401}),Response.json({isSuccess:false,statusCode:403}),
    Response.json({data:{fullName:'Synthetic Student',studentCardNumber:'invalid'}}),Response.json({data:{studentCardNumber:'999240001'}})]){
    const base=await listen(t,{studentDataCheck:{identityLookup:async()=>{lookups++;},
      fetchImpl:async url=>url===studentDataEndpoints.profile?profile:Response.json({data:[]})}});
    const body=await(await fetch(base+'/local-api/student-data-check',{headers:{Authorization:'Bearer test-token'}})).json();
    assert.equal(body.endpoints.identity.ok,false);
  }
  assert.equal(lookups,0);
  const base=await listen(t,{studentDataCheck:{identityLookup:async()=>{throw new Error('private database detail');},
    fetchImpl:async url=>Response.json({data:url===studentDataEndpoints.profile?{fullName:'Synthetic Student',studentCardNumber:'999240001'}:[]})}});
  const body=await(await fetch(base+'/local-api/student-data-check',{headers:{Authorization:'Bearer test-token'}})).json();
  assert.equal(body.endpoints.identity.status,503);assert.equal(body.endpoints.profile.ok,true);assert.equal(body.endpoints.stats.ok,true);
  assert.ok(!JSON.stringify(body).includes('private database detail'));
});
