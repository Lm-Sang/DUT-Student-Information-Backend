import assert from 'node:assert/strict';
import test from 'node:test';
import {createServer} from 'node:http';
import {EventEmitter} from 'node:events';
import {writeFile,mkdir} from 'node:fs/promises';
import express from 'express';
import {createAcademicLeaveModule} from '../../src/modules/academic-leave/index.js';
import {createAcademicLeavePrintAccess} from '../../src/modules/academic-leave/middlewares/academic-leave-print-access.js';
import {createPdfRenderer} from '../../src/infrastructure/pdf/chromium-pdf.js';
import {applicationView} from '../../src/modules/academic-leave/domain/academic-leave.rules.js';
import {renderAcademicLeavePrint} from '../../src/modules/academic-leave/mappers/academic-leave-print.mapper.js';
import {errorHandler} from '../../src/shared/middlewares/error-handler.middleware.js';
import {AppError} from '../../src/shared/errors/app-error.js';

const actor={role:'student',source:'auth',reference:'fixture',name:'Sinh viên kiểm thử',studentCode:'999260001'};
const fixture=()=>({id:1,studentSequence:1,requestCode:'NH9992600011',studentCode:actor.studentCode,kind:'leave',reasonCode:'medical',
  startSemesterCode:'2610',semesterCount:1,content:'',status:'submitted',studentConfirmedAt:'2026-10-26T09:44:00.000Z',rowVersion:'0000000000000001',
  snapshot:{student:{studentCode:actor.studentCode,fullName:'Sinh viên kiểm thử',birthday:'2005-02-20',phoneNumber:'0000000000',cccd:'000000000001',className:'TEST'},
    academicRows:Array.from({length:10},(_,i)=>({semester:(21+Math.floor(i/2))+(i%2?'20':'10'),credits:18,gpa:3.8,conduct:82}))}});

test('query print links use protected PDF responses, a short-lived cookie and a frozen confirmed snapshot',async t=>{
  let time=Date.parse('2026-10-26T10:00:00Z'),row=fixture(),authCalls=0,renders=0;
  const printAccess=createAcademicLeavePrintAccess({secret:'x'.repeat(32),now:()=>time});
  const module=createAcademicLeaveModule({printAccess,repository:{getByRequestCode:async(account,code)=>
    account.studentCode===row.studentCode&&code===row.requestCode?structuredClone(row):null},
    studentContextProvider:async req=>{authCalls++;if(req.headers.authorization!=='Bearer fixture-token')throw new AppError('Need login',401);return actor;},
    renderPdf:async html=>{renders++;assert.match(html,/BIÊN NHẬN/);return Buffer.from('%PDF-1.7\nfixture');}});
  const app=express();app.use(express.json());app.use(module.basePath,module.router);app.use(errorHandler);
  const server=createServer(app);await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>{server.close(resolve);server.closeAllConnections();}));
  const base='http://127.0.0.1:'+server.address().port+module.basePath;
  const headers={Authorization:'Bearer fixture-token'};
  assert.equal((await fetch(base+'/print?MADN='+row.requestCode)).status,401);
  assert.equal(renders,0);
  assert.equal((await fetch(base+'/print?MADN=invalid',{headers})).status,400);
  assert.equal((await fetch(base+'/print?MADN=NH9992600021',{headers})).status,404);
  const before=structuredClone(row);
  const direct=await fetch(base+'/print?MADN='+row.requestCode,{headers});
  assert.equal(direct.status,200);assert.match(direct.headers.get('content-type'),/^application\/pdf/);
  assert.equal(direct.headers.get('content-disposition'),'inline; filename="NH9992600011.pdf"');
  assert.equal(direct.headers.get('cache-control'),'private, no-store');assert.match(await direct.text(),/^%PDF-/);
  const session=await fetch(base+'/print-session',{method:'POST',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify({MADN:row.requestCode})});
  assert.equal(session.status,200);const access=(await session.json()).data;
  assert.equal(access.url,'/api/academic-leave/print?MADN=NH9992600011');assert.ok(!access.url.includes('fixture-token'));
  const setCookie=session.headers.get('set-cookie'),cookie=setCookie.split(';')[0];
  assert.match(setCookie,/HttpOnly/);assert.match(setCookie,/SameSite=Strict/);assert.match(setCookie,/Max-Age=300/);
  assert.ok(!setCookie.includes('fixture-token'));
  const authenticatedCalls=authCalls;
  for(let i=0;i<2;i++){
    const pdf=await fetch('http://127.0.0.1:'+server.address().port+access.url,{headers:{Cookie:cookie}});
    assert.equal(pdf.status,200);await pdf.arrayBuffer();
  }
  assert.equal(authCalls,authenticatedCalls);assert.deepEqual(row,before);
  assert.equal((await fetch(base+'/print?MADN=NH9992600012',{headers:{Cookie:cookie}})).status,401);
  assert.equal((await fetch(base+'/print?MADN='+row.requestCode,{headers:{Cookie:cookie+'tampered'}})).status,401);
  row.studentConfirmedAt='2026-10-26T10:01:00.000Z';
  assert.equal((await fetch(base+'/print?MADN='+row.requestCode,{headers:{Cookie:cookie}})).status,401);
  row=before;time+=300001;
  assert.equal((await fetch(base+'/print?MADN='+row.requestCode,{headers:{Cookie:cookie}})).status,401);
  row.status='needs_changes';assert.equal((await fetch(base+'/print?MADN='+row.requestCode,{headers})).status,409);
  assert.equal(renders,3);
});

test('PDF rendering bounds browser work, reuses the browser and isolates/cleans each document',async t=>{
  let release;const gate=new Promise(resolve=>{release=resolve;});let launchCount=0,pdfCount=0,closedContexts=0;
  const browser=new EventEmitter();browser.close=async()=>{};
  browser.createBrowserContext=async()=>({close:async()=>{closedContexts++;},newPage:async()=>({
    setJavaScriptEnabled:async value=>assert.equal(value,false),setRequestInterception:async value=>assert.equal(value,true),on:()=>{},
    setContent:async html=>assert.equal(html,'<html>fixture</html>'),pdf:async options=>{
      assert.equal(options.preferCSSPageSize,true);assert.equal(options.format,'A4');pdfCount++;if(pdfCount===1)await gate;return Buffer.from('%PDF-fixture');
    },
  })});
  const renderer=createPdfRenderer({executablePath:process.execPath,maxQueued:1,launch:async()=>{launchCount++;return browser;}});
  t.after(()=>renderer.close());
  const first=renderer.render('<html>fixture</html>');
  while(!pdfCount)await new Promise(resolve=>setTimeout(resolve,5));
  const second=renderer.render('<html>fixture</html>');
  await assert.rejects(renderer.render('<html>fixture</html>'),error=>error.statusCode===503);
  assert.deepEqual(renderer.stats,{active:1,queued:1});release();
  await Promise.all([first,second]);assert.equal(launchCount,1);assert.equal(closedContexts,2);
});

test('browser generates a real A4 PDF with Vietnamese text and receipt from ten semester rows',
  {skip:process.env.PDF_BROWSER_TEST!=='1'},async t=>{
  const renderer=createPdfRenderer();t.after(()=>renderer.close());
  const html=renderAcademicLeavePrint(applicationView(fixture()));
  const bytes=await renderer.render(html);
  assert.equal(bytes.subarray(0,5).toString(),'%PDF-');
  const pages=[...bytes.toString('latin1').matchAll(/\/Type\s*\/Page\b/g)].length;
  await mkdir('.data',{recursive:true});await writeFile('.data/academic-leave-sample.pdf',bytes);
  assert.equal(pages,1,'The standard ten-row document and receipt should fit one A4 page');
});
