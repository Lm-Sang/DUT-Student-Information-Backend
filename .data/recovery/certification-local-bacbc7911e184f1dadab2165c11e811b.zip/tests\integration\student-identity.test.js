import assert from 'node:assert/strict';
import test from 'node:test';
import sql from 'mssql';
import {createStudentService} from '../../src/modules/students/index.js';
import {createStudentRepository} from '../../src/modules/students/repositories/student.repository.js';

const actor={role:'student',studentCode:'999240001'};
const row=(citizenId,legacyIdentityNumber=null)=>({studentCode:actor.studentCode,citizenId,legacyIdentityNumber});

test('student identity prefers CCCD_So, supports 12-digit legacy values and never turns CMND or missing data into CCCD',async()=>{
  const cases=[
    {rows:[row('000000000001','000000000002')],status:'found',cccd:'000000000001',column:'CCCD_So'},
    {rows:[row(null,' 000000000002 ')],status:'found',cccd:'000000000002',column:'cmnd'},
    {rows:[row('invalid','123456789')],status:'missing',cccd:null},
    {rows:[row(null)],status:'missing',cccd:null},
    {rows:[],status:'not_found',cccd:null},
    {rows:[row('000000000001'),row('000000000001')],status:'ambiguous',cccd:null},
  ];
  for(const item of cases){
    const service=createStudentService({repository:{findIdentityRowsByStudentCode:async code=>{assert.equal(code,actor.studentCode);return item.rows;}}});
    const result=await service.getIdentityForAuthenticatedStudent(actor);
    assert.equal(result.status,item.status);assert.equal(result.cccd,item.cccd);
    if(item.column)assert.equal(result.source,'DATA_SV1.dbo.NhanThan.'+item.column);
  }
});

test('student identity rejects invalid actors before SQL, mismatched results and sanitized database failures',async()=>{
  let calls=0;
  const service=createStudentService({repository:{findIdentityRowsByStudentCode:async()=>{calls++;throw new Error('database credentials');}}});
  for(const input of [null,{role:'reviewer',studentCode:actor.studentCode},{role:'student',studentCode:"';DROP"},{role:'student',studentCode:999240001}])
    await assert.rejects(service.getIdentityForAuthenticatedStudent(input),error=>error.statusCode===403);
  assert.equal(calls,0);
  await assert.rejects(service.getIdentityForAuthenticatedStudent(actor),error=>error.statusCode===503&&!error.message.includes('credentials'));
  const mismatch=createStudentService({repository:{findIdentityRowsByStudentCode:async()=>[{...row('000000000001'),studentCode:'999240002'}]}});
  await assert.rejects(mismatch.getIdentityForAuthenticatedStudent(actor),error=>error.statusCode===502);
});

test('student identity repository reads the correct database with a bound char(9) MSSV and detects duplicate rows',async()=>{
  let statement,bound;
  const records=[row('000000000001'),row('000000000002')];
  const request={input(name,type,value){bound={name,type,value};return this;},async query(text){statement=text;return{recordset:records};}};
  const repository=createStudentRepository({connect:async(account,database)=>{
    assert.equal(account,'secondary');assert.equal(database,'DATA_SV1');return{request:()=>request};
  }});
  assert.deepEqual(await repository.findIdentityRowsByStudentCode(actor.studentCode),records);
  assert.equal(bound.name,'studentCode');assert.equal(bound.type.type,sql.Char);assert.equal(bound.type.length,9);assert.equal(bound.value,actor.studentCode);
  assert.match(statement,/TOP\(2\)/);assert.match(statement,/FROM dbo\.NhanThan WHERE MaHS = @studentCode/);
  assert.ok(!statement.includes(actor.studentCode));assert.doesNotMatch(statement,/\b(INSERT|UPDATE|DELETE|MERGE)\b/i);
});
