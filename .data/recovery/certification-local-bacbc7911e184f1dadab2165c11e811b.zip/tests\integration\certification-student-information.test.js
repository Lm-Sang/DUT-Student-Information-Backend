import assert from 'node:assert/strict';
import test from 'node:test';
import express from 'express';
import jwt from 'jsonwebtoken';
import { createDutStudentContext } from '../../src/modules/certifications/middlewares/dut-student-context.js';
import { createStudentService } from '../../src/modules/students/services/student.service.js';
import { createCertificationsService } from '../../src/modules/certifications/services/certifications.service.js';
import { createItCertificationsService } from '../../src/modules/certifications/services/it-certifications.service.js';
import { createCertificationsModule, createItCertificationsModule } from '../../src/modules/certifications/index.js';
import { parseIssuer, parsePreparation } from '../../src/modules/certifications/dto/certifications.request.dto.js';
import { errorHandler } from '../../src/shared/middlewares/error-handler.middleware.js';
import { MemoryRepository, MemoryStorage } from '../support/certifications.js';
import { MemoryItRepository } from '../support/it-certifications.js';
import { listen } from '../support/public-api.js';

const actor = { role:'student', source:'auth', reference:'fixture-student', studentCode:'999240001',
  cohortYear:2024, name:'Verified student', className:'24T1', cccd:'000000000001' };
const reviewer = { role:'reviewer', source:'auth', reference:'fixture-reviewer', name:'Reviewer' };
const config = { maxFiles:1, maxFileBytes:1024, uploadTtlSeconds:600, downloadTtlSeconds:60 };
const data = { certificateTypeId:1, issuingOrganizationId:1, issuedOn:'2026-01-01', result:{overall:5} };
const files = [{ purpose:'general', fileName:'fixture.png', contentType:'image/png', sizeBytes:4 }];
const expected = { studentCode:actor.studentCode, fullName:actor.name, className:actor.className, cccd:actor.cccd };
const information = row => Object.fromEntries(Object.keys(expected).map(key => [key,row[key]]));

test('SSO token fields are used only with a verified signature; authenticated profile fields are the fallback',async()=>{
  const ssoConfig={jwtSecret:'fixture-key-only',jwtIssuer:'fixture-sso'};
  const context=createDutStudentContext({ssoConfig,fetchImpl:async()=>Response.json({data:{studentCardNumber:actor.studentCode,
    fullName:'Profile name',class:{name:'Profile class'},cccd:'000000000002'}})});
  const claims={studentCode:actor.studentCode,fullName:actor.name,className:actor.className,cccd:actor.cccd};
  const signed=key=>jwt.sign(claims,key,{algorithm:'HS256',issuer:ssoConfig.jwtIssuer,expiresIn:'5m'});
  const result=await context({headers:{authorization:'Bearer '+signed(ssoConfig.jwtSecret)}});
  assert.equal(result.name,actor.name);assert.equal(result.className,actor.className);assert.equal(result.cccd,actor.cccd);
  const untrusted=await context({headers:{authorization:'Bearer '+signed('wrong-fixture-key')}});
  assert.equal(untrusted.name,'Profile name');assert.equal(untrusted.cccd,'000000000002');
  const mismatch=jwt.sign({...claims,studentCode:'999240002'},ssoConfig.jwtSecret,{issuer:ssoConfig.jwtIssuer,expiresIn:'5m'});
  await assert.rejects(context({headers:{authorization:'Bearer '+mismatch}}),error=>error.statusCode===403);
});

test('verified SSO information wins; missing fields use one read-only school lookup and keep leading CCCD zeroes', async () => {
  let queries=0;
  const service=createStudentService({ repository:{async findIdentityRowsByStudentCode(code) {
    queries++;assert.equal(code,actor.studentCode);
    return [{studentCode:code,fullName:'School name',className:'24DB',citizenId:'000000000002',legacyIdentityNumber:'123456789'}];
  }} });
  assert.deepEqual(await service.getCertificationProfile(actor),expected);assert.equal(queries,0);
  const missing=await service.getCertificationProfile({...actor,className:null,cccd:null});
  assert.deepEqual(missing,{...expected,className:'24DB',cccd:'000000000002'});assert.equal(queries,1);
  const legacy=createStudentService({repository:{findIdentityRowsByStudentCode:async()=>[
    {studentCode:actor.studentCode,legacyIdentityNumber:'123456789'}]}});
  assert.equal((await legacy.getCertificationProfile({...actor,cccd:null})).cccd,null);
});

for (const kind of ['language','it']) test(`${kind}: HTTP reviewer list/detail contains the verified identity; request bodies cannot replace it`, async t => {
  const repository=kind==='language'?new MemoryRepository():new MemoryItRepository(), storage=new MemoryStorage();
  const create=kind==='language'?createCertificationsModule:createItCertificationsModule;
  const module=create({repository,storage,config,inspectImage:async()=>({status:'needs_review',reasons:[]}),
    contextProvider:async (_req,role)=>role==='reviewer'?reviewer:actor});
  const app=express();app.use(express.json());app.use(module.basePath,module.router);app.use(errorHandler);
  const base=await listen(t,app)+module.basePath;
  const native=kind==='language'?{...data,fullName:'Spoofed name',className:'Spoofed class'}:{MaCC:'CNTT01',CoSoCapCC:'IT issuer'};
  const response=await fetch(base+'/applications',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data:native,files})});
  assert.equal(response.status,201);const prepared=(await response.json()).data;
  for(const upload of prepared.uploads)storage.objects.set(new URL(upload.url).pathname.slice(1),Buffer.from('test'));
  const complete=await fetch(base+'/applications/'+prepared.applicationId+'/complete',{method:'POST'});
  assert.equal(complete.status,200);assert.deepEqual(information((await complete.json()).data),expected);
  const detail=await fetch(base+'/reviewer/applications/'+prepared.applicationId).then(r=>r.json());
  const queue=await fetch(base+'/reviewer/applications').then(r=>r.json());
  assert.deepEqual(information(detail.data),expected);assert.deepEqual(information(queue.data.items[0]),expected);
  if(kind==='language')assert.equal(detail.data.issuingOrganization.displayName,'Fixture issuer');
  assert.equal(JSON.stringify(detail).includes('Spoofed'),false);
});

for (const kind of ['language','it']) test(`${kind}: missing identity stops submission before upload signing`,async()=>{
  const repository=kind==='language'?new MemoryRepository():new MemoryItRepository();let signed=0;
  const create=kind==='language'?createCertificationsService:createItCertificationsService;
  const service=create({repository,config,storage:{bucket:'fixture',async presignUpload(){signed++;}},
    studentProfile:async()=>({...expected,cccd:null})});
  await assert.rejects(service.prepare(actor,{data:kind==='language'?data:{MaCC:'CNTT01',CoSoCapCC:'Issuer'},files}),
    error=>error.statusCode===422&&error.details.fields.includes('cccd'));
  assert.equal(signed,0);
});

test('foreign language issuer must match the type and remain enabled until complete',async()=>{
  const repository=new MemoryRepository(),storage=new MemoryStorage();
  const service=createCertificationsService({repository,storage,config,inspectImage:async()=>({status:'needs_review'})});
  for(const value of [null,999])await assert.rejects(service.prepare(actor,{data:{...data,issuingOrganizationId:value},files}),
    error=>error.statusCode===422&&error.details.code==='CERT_ISSUER_NOT_ALLOWED');
  const prepared=await service.prepare(actor,{data,files});
  repository.catalogData.types[0].IssuingOrganizations[0].IsActive=false;
  await assert.rejects(service.complete(actor,prepared.applicationId),error=>error.details.code==='CERT_ISSUER_NOT_ALLOWED');
  assert.equal(repository.records.get(prepared.applicationId).Status,'uploading');
  assert.throws(()=>parsePreparation({data,files,cccd:'000000000001'},config),error=>error.statusCode===400);
  assert.throws(()=>parsePreparation({data:{...data,issuingOrganizationId:undefined},files},config),error=>error.details.field==='issuingOrganizationId');
});

test('issuer management validates sources, linked types and requires existing catalog permission',async()=>{
  const input={code:'TEST',displayName:'Issuer',isActive:true,sourceUrl:'https://issuer.example/about',verifiedOn:'2026-11-02',certificateTypeIds:[1]};
  assert.deepEqual(parseIssuer(input),input);
  for(const change of [{sourceUrl:'http://issuer.example'},{certificateTypeIds:[1,1]},{isActive:'true'},{verifiedOn:'2026-02-30'}])
    assert.throws(()=>parseIssuer({...input,...change}),error=>error.statusCode===400);
  const service=createCertificationsService({repository:new MemoryRepository(),config});
  await assert.rejects(service.saveCatalog(reviewer,'issuers',input),error=>error.statusCode===403);
});

test('historical applications get missing fields from school records after the ownership check',async()=>{
  const repository=new MemoryRepository();repository.records.set('legacy',{Id:'legacy',StudentCode:actor.studentCode,
    ActorReference:actor.reference,ActorSource:actor.source,FullName:actor.name,ClassName:actor.className,Files:[]});
  let calls=0;
  const service=createCertificationsService({repository,config,studentProfile:async input=>{calls++;assert.equal(input.studentCode,actor.studentCode);return expected;}});
  await assert.rejects(service.get({...actor,reference:'another-student'},'legacy'),error=>error.statusCode===403);
  assert.equal(calls,0);assert.deepEqual(information(await service.get(reviewer,'legacy')),expected);assert.equal(calls,1);
});
