import assert from 'node:assert/strict';
import test from 'node:test';
import {draft,review} from '../../src/modules/academic-leave/dto/academic-leave.request.dto.js';
import {semesterChoices,shiftSemester,validatePeriod,applicationView} from '../../src/modules/academic-leave/domain/academic-leave.rules.js';
import {renderAcademicLeavePrint} from '../../src/modules/academic-leave/mappers/academic-leave-print.mapper.js';
import {createAcademicLeaveService} from '../../src/modules/academic-leave/services/academic-leave.service.js';
import {normalizeAcademicStatistics} from '../../src/modules/students/services/student-application-data.service.js';

const input={kind:'leave',reasonCode:'medical',startSemesterCode:'2610',semesterCount:1,content:''};
test('leave permits four reasons and 1–4 terms, and refuses forged identity/snapshots/deadlines',()=>{
  for(const reasonCode of ['medical','accident','military','maternity'])for(const semesterCount of [1,2,3,4])
    assert.equal(draft({...input,reasonCode,semesterCount}).semesterCount,semesterCount);
  for(const override of [{semesterCount:0},{semesterCount:5},{semesterCount:1.5},{reasonCode:'other'},{startSemesterCode:'2621'},
    {studentCode:'999240001'},{snapshot:{}},{cccd:'000000000001'},{kind:'extension'},{kind:'leave',parentApplicationId:1}])
    assert.throws(()=>draft({...input,...override}),error=>error.statusCode===400);
  assert.throws(()=>review({decision:'approved',paperDeadlineAt:'2030-01-01'}),error=>error.statusCode===400);
  assert.throws(()=>review({decision:'rejected'}),error=>error.statusCode===400);
});
test('three selectable main terms roll across academic years and extensions must follow the approved parent',()=>{
  assert.deepEqual(semesterChoices('2610').map(item=>item.code),['2520','2610','2620']);
  assert.deepEqual(semesterChoices('2620').map(item=>item.code),['2610','2620','2710']);
  assert.equal(shiftSemester('2620',3).code,'2810');
  assert.throws(()=>validatePeriod({...input,startSemesterCode:'2510'},'2610'),error=>error.statusCode===409);
  const parent={status:'approved',startSemesterCode:'2610',semesterCount:1};
  assert.doesNotThrow(()=>validatePeriod({...input,kind:'extension',startSemesterCode:'2620'},'2610',parent));
  assert.throws(()=>validatePeriod({...input,kind:'extension'},'2610',parent),error=>error.statusCode===409);
  assert.throws(()=>validatePeriod({...input,kind:'extension',startSemesterCode:'2620'},'2610',{...parent,status:'submitted'}),error=>error.statusCode===409);
});
test('academic table preserves zero, null and semester alignment instead of shifting grades',()=>{
  const data={'Kỳ học':['2510','2520'],'GPA từng kỳ':[0,null],'Điểm rèn luyện từng kỳ':[80,0],'Số tín chỉ đăng ký từng kì':[18,21]};
  assert.deepEqual(normalizeAcademicStatistics(data),[{semester:'2510',credits:18,gpa:0,conduct:80},{semester:'2520',credits:21,gpa:null,conduct:0}]);
  assert.throws(()=>normalizeAcademicStatistics({...data,'GPA từng kỳ':[3.5]}),error=>error.statusCode===502);
});
test('printing uses the saved snapshot and escapes student-supplied text',()=>{
  const row=applicationView({...input,id:1,requestCode:'NH9992400011',status:'submitted',studentConfirmedAt:'2026-10-26T09:00:00Z',
    snapshot:{student:{studentCode:'999240001',fullName:'<script>bad</script>',birthday:'2005-02-20',phoneNumber:'0000000000',className:'TEST',cccd:'000000000001'},
      academicRows:[{semester:'2510',credits:18,gpa:0,conduct:null}]},content:'<img src=x onerror=bad>'});
  const html=renderAcademicLeavePrint(row);
  assert.match(html,/ĐƠN ĐỀ NGHỊ XÉT NGỪNG HỌC/);assert.match(html,/20\/02\/2005/);assert.match(html,/1 học kỳ/);
  assert.match(html,/BIÊN NHẬN/);assert.match(html,/Chuyên viên nhận hồ sơ/);
  assert.match(html,/000000000001/);assert.match(html,/&lt;script&gt;/);assert.match(html,/&lt;img/);assert.doesNotMatch(html,/<script>|<img/);
});
test('confirmation rejects incomplete profile before mutation and paper receipt rejects late requests',async()=>{
  let writes=0;
  const actor={role:'student',studentCode:'999240001'},row={...input,id:1,status:'draft',rowVersion:'0000000000000001'};
  const repository={get:async()=>row,currentSemesterCode:async()=> '2610',confirm:async()=>{writes++;}};
  const service=createAcademicLeaveService({repository,snapshotProvider:async()=>({student:{studentCode:actor.studentCode,fullName:'Fixture',birthday:'2005-02-20',className:'TEST',phoneNumber:'0000000000',cccd:null},academicRows:[]})});
  await assert.rejects(service.confirm(actor,1,row.rowVersion,'fixture'),error=>error.statusCode===422);assert.equal(writes,0);
  await assert.rejects(service.confirm(actor,1,'0000000000000002','fixture'),error=>error.statusCode===409);
  const late=createAcademicLeaveService({repository:{get:async()=>({...row,status:'approved',paperDeadlineAt:'2026-10-20T00:00:00Z'}),receivePaper:async()=>{writes++;}},clock:()=>new Date('2026-10-26T00:00:00Z')});
  await assert.rejects(late.receivePaper({role:'reviewer'},1,row.rowVersion),error=>error.statusCode===409);assert.equal(writes,0);
});
