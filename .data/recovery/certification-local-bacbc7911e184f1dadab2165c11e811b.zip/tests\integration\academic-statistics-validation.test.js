import assert from 'node:assert/strict';
import test from 'node:test';
import {normalizeAcademicRows,normalizeAcademicStatistics} from '../../src/modules/students/validators/academic-statistics.validator.js';
import {createAcademicLeaveService} from '../../src/modules/academic-leave/services/academic-leave.service.js';
import {renderAcademicLeavePrint} from '../../src/modules/academic-leave/mappers/academic-leave-print.mapper.js';

const row=(semester,credits=24,gpa=3.82,conduct=87)=>({semester,credits,gpa,conduct});
const sample=()=>[
  row('2310',18,3.83,82),row('2320'),row('2321'),row('2410',19,3.75,82),
  row('2420',21,3.8),row('2421',21,3.8),row('2510',18,3.83,90),
  row('2520',14,3.82,90),row('2521',14,3.82,90),row('2610',10,null,0),
];
test('the ten-row example collapses summer aliases into seven main terms without changing any main-term result',()=>{
  const rows=sample(),before=structuredClone(rows);
  const result=normalizeAcademicStatistics({semesters:rows.map(item=>item.semester),creditsPerSemester:rows.map(item=>item.credits),
    gpaPerSemester:rows.map(item=>item.gpa),conductPerSemester:rows.map(item=>item.conduct)});
  assert.deepEqual(result,rows.filter(item=>!item.semester.endsWith('21')));
  assert.deepEqual(result.map(item=>item.semester),['2310','2320','2410','2420','2510','2520','2610']);
  assert.equal(result[1].credits,24);assert.equal(result[3].credits,21);assert.equal(result[5].credits,14);
  assert.deepEqual(result.at(-1),row('2610',10,null,0));assert.deepEqual(rows,before);
});
test('main-term data wins over a summer alias regardless of row order, without adding or averaging grades',()=>{
  assert.deepEqual(normalizeAcademicRows([row('2321',4,2,20),row('2320',24,3.82,87)]),[row('2320')]);
  assert.deepEqual(normalizeAcademicRows([row('2320'),row('2321',4,2,20)]),[row('2320')]);
  assert.deepEqual(normalizeAcademicRows([row('2321',4,2,20),row('2321',5,3,30),row('2320')]),[row('2320')]);
});
test('a summer-only record is retained under term two and identical results in different years stay separate',()=>{
  assert.deepEqual(normalizeAcademicRows([row('2321')]),[row('2320')]);
  assert.deepEqual(normalizeAcademicRows([row('2320'),row('2420')]),[row('2320'),row('2420')]);
  assert.deepEqual(normalizeAcademicRows([row('2320'),row('2320')]),[row('2320')]);
  assert.deepEqual(normalizeAcademicRows([row('2 / 2023-2024'),row('2321')]),[row('2320')]);
  assert.deepEqual(normalizeAcademicRows([row('Học kỳ 2 năm học 2023-2024'),row('2320')]),[row('2320')]);
});
test('conflicting main records, invalid numbers and misaligned arrays are rejected rather than silently combined',()=>{
  for(const rows of [[row('2320'),row('2320',20)], [row('2321'),row('2321',20)], [row('2320',Infinity)], [row('2320',24,true)]])
    assert.throws(()=>normalizeAcademicRows(rows),error=>error.statusCode===502);
  assert.throws(()=>normalizeAcademicStatistics({'Kỳ học':['2320','2321'],'GPA từng kỳ':[3.82],
    'Số tín chỉ đăng ký từng kì':[24,24],'Điểm rèn luyện từng kỳ':[87,87]}),error=>error.statusCode===502);
  assert.deepEqual(normalizeAcademicRows([row('2320','24','3,82','87')]),[row('2320')]);
  assert.deepEqual(normalizeAcademicRows([row('2320',0,' ',0)]),[row('2320',0,null,0)]);
});
const actor={role:'student',source:'auth',reference:'fixture',studentCode:'999260001'};
const snapshot=()=>({student:{studentCode:actor.studentCode,fullName:'Synthetic Student',birthday:'2005-02-20',phoneNumber:'0000000000',className:'TEST',cccd:'000000000001'},academicRows:sample()});
const application=()=>({id:1,requestCode:'NH9992600011',studentCode:actor.studentCode,kind:'leave',reasonCode:'medical',startSemesterCode:'2610',semesterCount:1,
  parentApplicationId:null,content:'',status:'submitted',rowVersion:'0000000000000001',studentConfirmedAt:'2026-10-26T09:00:00Z',snapshot:snapshot()});
test('existing confirmed snapshots are normalized for detail and both print methods without rewriting the saved snapshot',async()=>{
  const stored=application(),before=structuredClone(stored);
  const service=createAcademicLeaveService({repository:{get:async()=>stored,getByRequestCode:async()=>stored}});
  for(const result of [await service.get(actor,1),await service.printable(actor,1),await service.printableByCode(actor,stored.requestCode)]){
    assert.equal(result.snapshot.academicRows.length,7);assert.equal(result.rowVersion,stored.rowVersion);
    const html=renderAcademicLeavePrint(result);assert.doesNotMatch(html,/2321|2421|2521/);assert.match(html,/2 \/ 2023-2024/);
  }
  assert.deepEqual(stored,before);assert.equal(stored.snapshot.academicRows.length,10);
});
test('confirmation stores normalized complete rows before writing a new snapshot',async()=>{
  const source=snapshot(),before=structuredClone(source),draft={...application(),status:'draft',snapshot:null};let saved;
  const service=createAcademicLeaveService({snapshotProvider:async()=>source,repository:{get:async()=>draft,currentSemesterCode:async()=> '2610',
    confirm:async(_actor,_id,_expected,clean)=>{saved=clean;return{...draft,status:'submitted',snapshot:clean};}}});
  const result=await service.confirm(actor,1,draft.rowVersion,'fixture');
  assert.equal(saved.academicRows.length,7);assert.equal(result.snapshot.academicRows.length,7);assert.deepEqual(source,before);
  assert.deepEqual(normalizeAcademicRows(saved.academicRows),saved.academicRows);
});
