import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import { queryLocalDatabase, disconnectLocalDatabase } from '../../src/infrastructure/database/local-sql-server.js';
import { createCertificationsRepository } from '../../src/modules/certifications/repositories/certifications.repository.js';
import { createItCertificationsRepository } from '../../src/modules/certifications/repositories/it-certifications.repository.js';
import { createCertificationsService } from '../../src/modules/certifications/services/certifications.service.js';
import { createItCertificationsService } from '../../src/modules/certifications/services/it-certifications.service.js';
import { MemoryStorage } from '../support/certifications.js';

// Clone only table definitions/defaults into a uniquely named schema. No student
// records or real evidence objects are copied, submitted or reviewed.
test('SQL migration is repeatable; both repositories persist student snapshots and enforce the foreign language issuer link',
  {skip:process.env.CERT_STUDENT_DB_TEST!=='1',timeout:60000},async()=>{
  const schema='cert_info_test_'+randomUUID().replaceAll('-','');
  const tables=['Languages','CertificateTypes','CertificateLevels','RecognitionPolicies','StudentCertificates','EvidenceFiles',
    'tmCNTTChungChi','tmCNTTChungChi_SV','tmCNTTChungChi_File'];
  const query=(statement,params=[])=>queryLocalDatabase(statement.replaceAll('certification.',schema+'.'),params);
  const actor={role:'student',source:'auth',reference:'synthetic-sql',studentCode:'999240001',cohortYear:2024,
    name:'Synthetic SQL Student',className:'SQL24',cccd:'000000000001'};
  const reviewer={role:'reviewer',source:'auth',reference:'synthetic-reviewer',name:'SQL Reviewer'};
  const config={maxFiles:1,maxFileBytes:1024,uploadTtlSeconds:600,downloadTtlSeconds:60};
  const fields=row=>[row.fullName,row.studentCode,row.className,row.cccd];
  const expected=[actor.name,actor.studentCode,actor.className,actor.cccd];
  try {
    await queryLocalDatabase(`CREATE SCHEMA ${schema}`);
    for(const table of tables){
      const metadata=(await queryLocalDatabase(`SELECT c.name,c.system_type_id,c.is_identity,d.definition
        FROM sys.columns c LEFT JOIN sys.default_constraints d ON d.object_id=c.default_object_id
        WHERE c.object_id=OBJECT_ID(?) ORDER BY c.column_id`,['certification.'+table])).first;
      assert.ok(metadata.length,'Missing certification base table '+table);
      const columns=metadata.filter(c=>c.system_type_id!==189).map(c=>'['+c.name.replaceAll(']',']]')+']').join(',');
      await queryLocalDatabase(`SELECT TOP(0) ${columns} INTO ${schema}.${table} FROM certification.${table};
        ALTER TABLE ${schema}.${table} ADD PRIMARY KEY(${metadata.find(c=>c.name.toLowerCase()==='id').name});`);
      for(const column of metadata){
        if(column.system_type_id===189)await queryLocalDatabase(`ALTER TABLE ${schema}.${table} ADD [${column.name}] rowversion`);
        if(column.definition)await queryLocalDatabase(`ALTER TABLE ${schema}.${table} ADD DEFAULT ${column.definition} FOR [${column.name}]`);
      }
    }
    const migration=await readFile('docs/sql/certifications-student-information-issuers.sql','utf8');
    await query(migration);await query(migration);
    await query(`INSERT certification.Languages(Code,DisplayName,IsPublished) VALUES(N'TEST',N'Fixture',1);
      INSERT certification.CertificateTypes(LanguageId,Code,DisplayName,FormSchemaJson,IsPublished)
        SELECT Id,N'IELTS',N'Fixture IELTS',N'{"fields":[{"key":"overall","label":"Overall","type":"number","required":true,"min":0,"max":9,"step":0.5}]}',1
        FROM certification.Languages;
      INSERT certification.RecognitionPolicies(LanguageId,CohortFrom,IsRecognized) SELECT Id,1900,1 FROM certification.Languages;
      INSERT certification.tmCNTTChungChi(MaCC,TenCC) VALUES(N'CNTT01',N'Fixture IT');`);
    const seed=await readFile('docs/sql/certifications-issuers-seed.sql','utf8');
    await query(seed);await query(seed);
    const languageRepo=createCertificationsRepository({query,databaseName:'Studentpage',databaseHost:'localhost'});
    const itRepo=createItCertificationsRepository({query,databaseName:'Studentpage',databaseHost:'localhost'});
    const catalog=await languageRepo.catalog(),type=catalog.types[0],issuer=type.IssuingOrganizations[0];
    assert.equal(catalog.issuers.length,47);assert.equal(type.IssuingOrganizations.length,2);
    assert.deepEqual(catalog.issuers.find(i=>i.Id===issuer.Id).CertificateTypeIds,[type.Id]);
    const files=[{purpose:'general',fileName:'synthetic.png',contentType:'image/png',sizeBytes:4}];
    for(const [kind,repository,createService,data] of [
      ['language',languageRepo,createCertificationsService,{certificateTypeId:type.Id,issuingOrganizationId:issuer.Id,issuedOn:'2026-01-01',result:{overall:5}}],
      ['it',itRepo,createItCertificationsService,{MaCC:'CNTT01',CoSoCapCC:'Synthetic issuer'}],
    ]){
      const storage=new MemoryStorage(),service=createService({repository,storage,config,inspectImage:async()=>({status:'needs_review',reasons:[]})});
      const prepared=await service.prepare(actor,{data,files});
      for(const upload of prepared.uploads)storage.objects.set(new URL(upload.url).pathname.slice(1),Buffer.from('test'));
      const completed=await service.complete(actor,prepared.applicationId);
      assert.equal(completed.status,'submitted',kind);assert.deepEqual(fields(completed),expected);
      const detail=await service.get(reviewer,prepared.applicationId);
      const queue=await service.list(reviewer,{page:1,pageSize:20,status:'submitted'});
      assert.deepEqual(fields(detail),expected);assert.deepEqual(fields(queue.items[0]),expected);
      if(kind==='it')assert.deepEqual(fields((await service.records(reviewer,{page:1,pageSize:20})).items[0]),expected);
      if(kind==='language'){
        const manager={...reviewer,permissions:['certifications:catalog:manage']};
        const updated=await service.saveCatalog(manager,'issuers',{code:issuer.Code,displayName:'Changed catalog name',isActive:true,
          sourceUrl:'https://example.test/issuer',verifiedOn:'2026-11-02',certificateTypeIds:[type.Id]},issuer.Id,issuer.VersionToken);
        assert.equal(updated.displayName,'Changed catalog name');
        assert.equal((await service.get(reviewer,prepared.applicationId)).issuingOrganization.displayName,issuer.DisplayName);
        await assert.rejects(service.saveCatalog(manager,'issuers',{code:issuer.Code,displayName:'Stale update',isActive:true,
          sourceUrl:'https://example.test/issuer',verifiedOn:'2026-11-02',certificateTypeIds:[type.Id]},issuer.Id,issuer.VersionToken),e=>e.statusCode===409);
        const unrelated=catalog.issuers.find(i=>i.Code==='ETS');
        await assert.rejects(query('UPDATE certification.StudentCertificates SET IssuingOrganizationId=? WHERE Id=?',[unrelated.Id,prepared.applicationId]),/FOREIGN KEY/i);
        await assert.rejects(query('UPDATE certification.StudentCertificates SET Cccd=? WHERE Id=?',['123456789',prepared.applicationId]),/CHECK/i);
      }
    }
  } finally {
    if(!/^cert_info_test_[a-f0-9]{32}$/.test(schema))throw new Error('Unexpected test schema');
    for(const table of ['EvidenceFiles','StudentCertificates','CertificateTypeIssuers','IssuingOrganizations','CertificateLevels','RecognitionPolicies',
      'CertificateTypes','Languages','tmCNTTChungChi_File','tmCNTTChungChi_SV','tmCNTTChungChi'])
      await queryLocalDatabase(`DROP TABLE IF EXISTS ${schema}.${table}`);
    await queryLocalDatabase(`DROP SCHEMA IF EXISTS ${schema}`);
    await disconnectLocalDatabase();
  }
});
