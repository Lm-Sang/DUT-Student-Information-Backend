import assert from 'node:assert/strict';
import { test } from 'node:test';
import { existsSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import puppeteer from 'puppeteer-core';
import { createAuthService } from '../../src/modules/auth/services/auth.service.js';
import { createAuthStore } from '../../src/modules/auth/stores/auth.store.js';
import { hashPassword } from '../../src/modules/auth/services/password.service.js';
import { createAuthModule, createSsoTokenResolver, createLocalPermissionContext } from '../../src/modules/auth/index.js';
import { createDutStudentContext } from '../../src/modules/students/index.js';
import { createCertificationsModule } from '../../src/modules/certifications/index.js';
import { createItCertificationsModule } from '../../src/modules/certifications/index.js';
import { createAcademicLeaveModule } from '../../src/modules/academic-leave/index.js';
import { createCertificationEvents } from '../../src/modules/certifications/events/certification-events.js';
import { certificationConfig } from '../../src/config/certifications.js';
import { errorHandler } from '../../src/shared/middlewares/error-handler.middleware.js';
import { createWebTestApp } from '../../certification-web-test/server.js';
import { MemoryRepository, MemoryStorage } from '../support/certifications.js';
import { MemoryItRepository } from '../support/it-certifications.js';
import { listen } from '../support/public-api.js';

test('browser uses the original SSO token across student modules and separate password/JWT sessions for staff',
  { skip: process.env.AUTH_BROWSER_TEST !== '1', timeout: 90000 }, async t => {
    const executablePath = [process.env.PDF_BROWSER_EXECUTABLE,
      'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'].find(path => path && existsSync(path));
    assert.ok(executablePath, 'An installed Chromium browser is required');
    const studentApp = express(), adminApp = express(), backend = express(), gateway = express();
    const studentBase = await listen(t, studentApp), adminBase = await listen(t, adminApp);
    const apiBase = await listen(t, backend), ssoBase = await listen(t, gateway);
    const config = { nodeEnv: 'test', auth: { stateTtlMs: 600000, handoffTtlMs: 60000, refreshTtlSeconds: 604800 },
      jwt: { secret: 'browser-app-fixture-secret-never-for-production', expiresIn: '15m', issuer: 'browser-test', studentAudience: 'browser-student', adminAudience: 'browser-admin' },
      app: { url: apiBase, studentFrontendUrl: studentBase, adminFrontendUrl: adminBase },
      microsoftSso: { jwtSecret: 'browser-sso-fixture-secret-never-for-production', jwtIssuer: 'https://sso.dut.udn.vn', allowMissingAudience: true,
        baseUrl: ssoBase, loginPath: '/microsoft/login', logoutPath: '/microsoft/logout',
        studentCallbackUrl: apiBase + '/api/student/auth/microsoft/callback', studentFrontendCallbackUrl: studentBase + '/auth-callback.html' } };
    const password = randomBytes(24).toString('base64url');
    const account = { id: '00000000-0000-4000-8000-000000000002', username: 'staff.browser', displayName: 'Browser Staff Fixture',
      channel: 'admin', passwordHash: await hashPassword(password), isActive: true, version: 'fixture-version', roles: ['reviewer'], permissions: ['certifications:review','academic-leave:review'] };
    const repository = { findLocalByUsername: async value => value === account.username ? account : null,
      findLocalById: async value => value === account.id ? account : null };
    const store = createAuthStore(), events = createCertificationEvents();
    t.after(() => { events.closeAll(); store.close(); });
    const service = createAuthService({ config, repository, store });
    const upstream = jwt.sign({ sub: 'browser-sso-user', unique_name: 'synthetic@dut.udn.vn' }, config.microsoftSso.jwtSecret,
      { algorithm: 'HS256', issuer: config.microsoftSso.jwtIssuer, expiresIn: '1h' });
    gateway.get('/microsoft/login', (req, res) => {
      const callback = new URL(req.query.callbackUrl);
      assert.equal(callback.origin, apiBase);
      callback.searchParams.set('accessToken', upstream);
      res.redirect(303, callback.href);
    });
    backend.use(cors({ origin: [studentBase, adminBase], credentials: true }), express.json());
    for (const channel of ['student', 'admin']) {
      const module = createAuthModule({ channel, service, frontendOrigin: channel === 'student' ? studentBase : adminBase });
      backend.use(module.basePath, module.router);
    }
    let profileCalls = 0;
    const studentContextProvider = createDutStudentContext({ ssoTokenResolver: createSsoTokenResolver(service), fetchImpl: async (_url, options) => {
      profileCalls++; assert.equal(options.headers.Authorization, 'Bearer ' + upstream);
      return Response.json({ data: { studentCardNumber: '999240001', fullName: 'Browser Student Fixture', cccd:'000000000001',
        birthday:'2005-01-01',phoneNumber:'0900000001',class: { name: 'TEST' } } });
    } });
    const certifications = createCertificationsModule({ repository: new MemoryRepository(), storage: new MemoryStorage(),
      config: { ...certificationConfig, r2: { ...certificationConfig.r2, privateConfirmed: true } },
      studentContextProvider, reviewerAuthentication: { actor: createLocalPermissionContext('certifications:review', service) }, events });
    const it=createItCertificationsModule({repository:new MemoryItRepository(),storage:new MemoryStorage(),studentContextProvider,
      reviewerAuthentication:{actor:createLocalPermissionContext('certifications:review',service)},events});
    const leave=createAcademicLeaveModule({studentContextProvider,reviewerContextProvider:createLocalPermissionContext('academic-leave:review',service),
      repository:{currentSemesterCode:async()=> '2610',eligibleParents:async()=>[],
        list:async()=>({page:1,pageSize:20,totalRecords:0,totalPages:1,items:[]})},
      snapshotProvider:async(actor,token)=>{
        assert.equal(token,upstream);
        return{student:{studentCode:actor.studentCode,fullName:actor.name,birthday:actor.birthday,phoneNumber:actor.phoneNumber,
          className:actor.className,cccd:'000000000001'},academicRows:[{semester:'2610',credits:18,gpa:3.5,conduct:90}]};
      }});
    for(const module of [certifications,it,leave])backend.use(module.basePath,module.router);
    backend.use(errorHandler);
    const frontend = { apiBaseUrl: apiBase, ssoBaseUrl: ssoBase, studentOrigin: studentBase, reviewerOrigin: adminBase };
    studentApp.use(createWebTestApp(frontend)); adminApp.use(createWebTestApp({ ...frontend, mode: 'reviewer' }));
    const browser = await puppeteer.launch({ executablePath, headless: true });
    try {
      const page = await browser.newPage(), errors = [];
      page.on('pageerror', error => errors.push(error.message));
      await page.goto(studentBase, { waitUntil: 'domcontentloaded' });
      await page.waitForFunction(() => document.querySelector('#connection').textContent.includes('Backend:'));
      await page.click('#academic-leave-tab');
      await page.waitForFunction(() => location.pathname==='/academic-leave.html'&&!document.querySelector('#student-auth').hidden);
      await page.click('#login');
      await page.waitForFunction(() => location.pathname==='/academic-leave.html'&&!document.querySelector('#editor').hidden);
      assert.ok((await page.$eval('#prefill',element=>element.textContent)).includes('Browser Student Fixture'));
      assert.equal(await page.evaluate(async()=> (await import('/web-auth.js')).getAccessToken()),upstream);
      await page.goto(studentBase+'/?kind=language',{waitUntil:'domcontentloaded'});
      await page.waitForFunction(() => document.querySelector('#identity')?.textContent.includes('Browser Student Fixture'));
      await page.click('#it-tab');
      await page.waitForFunction(() => document.querySelector('#identity')?.textContent.includes('Browser Student Fixture')&&document.querySelector('#it-MaCC'));
      assert.equal(await page.evaluate(async()=> (await import('/web-auth.js')).getAccessToken()),upstream);
      await page.click('#language-tab');
      await page.waitForFunction(() => document.querySelector('#identity')?.textContent.includes('Browser Student Fixture'));
      assert.ok(profileCalls > 0);
      assert.equal(await page.evaluate(() => !Object.keys(sessionStorage).some(key => /token/i.test(key)) && localStorage.length === 0), true);
      const cdp = await page.createCDPSession();
      const cookieState = await cdp.send('Network.getCookies', { urls: [apiBase + '/api/student/auth/refresh'] });
      assert.equal(cookieState.cookies.find(cookie => cookie.name === 'dut_web_student_refresh')?.httpOnly, true);
      assert.match(cookieState.cookies.find(cookie => cookie.name === 'dut_web_student_refresh').value,/^[A-Za-z0-9_-]{43}$/);
      const token = await page.evaluate(async () => (await import('/web-auth.js')).getAccessToken());
      await service.verifyToken(token, 'student');
      assert.equal(token, upstream);
      await page.reload({ waitUntil: 'domcontentloaded' });
      await page.waitForFunction(() => document.querySelector('#identity')?.textContent.includes('Browser Student Fixture'));
      const twin = await browser.newPage();
      await twin.goto(studentBase, { waitUntil: 'domcontentloaded' });
      await twin.waitForFunction(() => document.querySelector('#identity')?.textContent.includes('Browser Student Fixture'));
      await Promise.all([page, twin].map(tab => tab.evaluate(async () => {
        await (await import('/web-auth.js')).restoreWebSession();
        return true;
      })));
      await service.verifyToken(token, 'student');
      assert.equal(await page.evaluate(async () => {
        try { await (await import('/web-auth.js')).webAuthFetch('https://untrusted.example/'); return false; }
        catch { return true; }
      }), true);
      await twin.close();
      await page.click('#logout');
      await page.waitForFunction(() => !document.querySelector('#login').hidden);
      await assert.rejects(service.verifyToken(token, 'student'), error => error.statusCode === 401);
      const beforeStaff = profileCalls;
      const staff = await browser.newPage(); staff.on('pageerror', error => errors.push(error.message));
      await staff.goto(adminBase, { waitUntil: 'domcontentloaded' });
      await staff.waitForFunction(() => !document.querySelector('#reviewer-login').disabled);
      await staff.type('#reviewer-username', account.username); await staff.type('#reviewer-password', password);
      await staff.click('#reviewer-login');
      await staff.waitForFunction(() => !document.querySelector('#reviewer-session').hidden && document.querySelector('#reviewer-name').textContent === 'Browser Staff Fixture');
      const staffToken=await staff.evaluate(async()=> (await import('/web-auth.js')).getAccessToken());
      assert.equal(jwt.decode(staffToken,{complete:true}).header.typ,'at+jwt');assert.notEqual(staffToken,upstream);
      await staff.click('#academic-leave-tab');
      await staff.waitForFunction(() => location.pathname==='/academic-leave.html'&&!document.querySelector('#list-card').hidden);
      assert.equal((await service.verifyToken(await staff.evaluate(async()=> (await import('/web-auth.js')).getAccessToken()),'admin')).authMethod,'password');
      assert.equal(profileCalls, beforeStaff);
      assert.deepEqual(errors, []);
    } finally { await browser.close(); }
  });
